import subprocess
os.system('powershell -Command Get-Process')
eval('1+1')